/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pokerdice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 *
 * @author Aluno
 */
public class Game {

    private static Random random = new Random();

    public static int[] gererateDiceThrow() {
        int[] numbers = new int[5];

        for (int i = 0; i < 5; i++) {
            numbers[i] = generateRandomDiceNumber();
        }

        return numbers;
    }

    public static int generateRandomDiceNumber() {
        return random.nextInt(6) + 1;   //Gera numeros de 0 a 6...random.nextInt(6) gera numeros de 0 a 5 e soma-se um para ficar no intervalo correto
    }

    public static String printScores(int[] player1, int[] player2) {
        String result = "Player 1 -> " + Arrays.toString(player1) + "\nPlayer 2 -> " + Arrays.toString(player2) + "\n";

        System.out.println(result);

        return result;
    }

    public static int calculateScore(int[] playerScore) {
        int ranking = 0;
        int[] ocurrencyArray = {0, 0, 0, 0, 0, 0};

        //Agora que vem o dificil...
        //Checa a ocorrencia dos numeros
        int[] occurencies = calculateOcurrencies(playerScore);
        System.out.println("\tOcorrências: " + Arrays.toString(occurencies));    //o index 0 é a ocorrencia do numero 1, o index 2 do numero 2..

        boolean isQuina = isQuina(occurencies);
        boolean isSequencia = isSequencia(occurencies);
        boolean isQuadra = isQuadra(occurencies);
        boolean isTrinca = isTrinca(occurencies);
        boolean isPar = isPar(occurencies);
        boolean isTrincaPar = isTrincaPar(occurencies);

        if (isQuina) {
            ranking = 10;
            System.out.println("\tQuina !");
        } else if (isSequencia) {
            ranking = 9;
            System.out.println("\tSequência !");
        } else if (isSequencia) {
            ranking = 8;
            System.out.println("\tQuadra !");
        } else if (isTrincaPar) {
            ranking = 7;
            System.out.println("\tTrinca e Par !");
        } else if (isTrinca) {
            System.out.println("\tTrinca !");
            ranking = 6;
        } else if (isPar) {
            System.out.println("\tPar !");
            ranking = 5;
        } else {
            System.out.println("\tNadica de nada !");
            ranking = 4;
        }

        return ranking; //> sum ? ranking : sum;
    }

    public static int compareScores(int player1, int player2) {
        return player1 > player2 ? 1 : 2;
    }

    public static int[] calculateOcurrencies(int[] playerScore) {
        int[] ocurrencyArray = {0, 0, 0, 0, 0, 0};

        for (int i = 0; i < 5; i++) {
            int lastValidNumber = playerScore[i];
            int ocurencies = 0;

            for (int value : playerScore) {
                if (value != lastValidNumber) {
                    continue;
                } else {
                    ocurencies++;
                }
                ocurrencyArray[lastValidNumber - 1] = ocurencies;
                lastValidNumber = value;
            }
        }

        return ocurrencyArray;
    }

    public static boolean isQuina(int[] ocurencies) {
        for (int ocurency : ocurencies) {
            if (ocurency == 5) {
                return true;
            }
        }

        return false;
    }

    public static boolean isSequencia(int[] ocurencies) {
        for (int ocurency : ocurencies) {
            if (ocurency == 1) {
                continue;
            } else {
                return false;
            }
        }

        return true;
    }

    public static boolean isQuadra(int[] ocurencies) {
        for (int ocurency : ocurencies) {
            if (ocurency == 4) {
                return true;
            }
        }

        return false;
    }

    public static boolean isTrincaPar(int[] ocurencies) {
        boolean hasTrinca = isTrinca(ocurencies);
        boolean hasPar = isPar(ocurencies);

        return hasTrinca && hasPar;
    }

    public static boolean isTrinca(int[] ocurencies) {
        boolean hasTrinca = false;

        for (int ocurency : ocurencies) {
            if (ocurency == 3) {
                hasTrinca = true;
            }
        }

        return hasTrinca;
    }

    public static boolean isPar(int[] ocurencies) {
        boolean hasTrinca = false;
        boolean hasPar = false;

        for (int ocurency : ocurencies) {
            if (ocurency == 2) {
                hasPar = true;
            }
        }

        return hasPar;
    }

    public static int untie(int[] player1, int[] player2) {
        //----------------------OCURRENCY----------------------
        int[] courrency1 = calculateOcurrencies(player1);
        int[] courrency2 = calculateOcurrencies(player2);

        int biggestOcurrency1 = 0;
        int biggestOcurrencyIndex1 = 0;

        int biggestOcurrency2 = 0;
        int biggestOcurrencyIndex2 = 0;
        for (int i = 0; i < 5; i++) {
            if (courrency1[i] > biggestOcurrency1) {
                biggestOcurrency1 = courrency1[i];
                biggestOcurrencyIndex1 = i;
            }
        }

        for (int i = 0; i < 5; i++) {
            if (courrency2[i] > biggestOcurrency2) {
                biggestOcurrency2 = courrency2[i];
                biggestOcurrencyIndex2 = i;
            }
        }

        //------------------- RESULT -------------------------
        return biggestOcurrencyIndex1 > biggestOcurrencyIndex2 ? 1 : 2;
    }
}
