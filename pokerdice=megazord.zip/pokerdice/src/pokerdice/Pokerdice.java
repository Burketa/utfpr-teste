package pokerdice;

import java.util.Arrays;

/**
 *
 * @author burca
 */
public class Pokerdice {

    public static void main(String[] args) {
        Game generator = new Game();

       int[] player1 = Game.gererateDiceThrow();
       int[] player2 = Game.gererateDiceThrow();
       
        Game.printScores(player1, player2);

        System.out.println("Avaliando Player 1:");
        int player1Score = Game.calculateScore(player1);

        System.out.println("\nAvaliando Player 2:");
        int player2Score = Game.calculateScore(player2);

        System.out.println("\nCalculando Vencedor:");
        int winnerPlayer = Game.compareScores(player1Score, player2Score);

        if (player1Score == player2Score) {
            System.out.println("\tUau, empatou ! Desempatando:\n");
            winnerPlayer = Game.untie(player1, player2);
        }

        System.out.println("\tO jogador " + winnerPlayer + " venceu !");

    }
}
