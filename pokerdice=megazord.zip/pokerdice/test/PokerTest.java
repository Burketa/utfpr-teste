/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import pokerdice.Game;

/**
 *
 * @author Aluno
 */
public class PokerTest {

    int[] player1 = Game.gererateDiceThrow();
    int[] player2 = Game.gererateDiceThrow();

    public PokerTest() {
    }

    @Test
    public void isQuinaTeste() {
        int[] numberArray = {0, 0, 0, 0, 0, 5};
        assertTrue(Game.isQuina(numberArray));
    }

    @Test
    public void isSequenciaTeste() {
        int[] numberArray = {0, 1, 1, 1, 1, 1};
        assertTrue(Game.isSequencia(numberArray));
    }

    @Test
    public void isQuadraTeste() {
        int[] numberArray = {0, 0, 0, 0, 1, 4};
        assertTrue(Game.isQuadra(numberArray));
    }

    @Test
    public void isTrincaParTeste() {
        int[] numberArray = {0, 0, 0, 0, 2, 3};
        assertTrue(Game.isTrincaPar(numberArray));
    }

    @Test
    public void isTrincaTeste() {
        int[] numberArray = {0, 0, 0, 1, 1, 3};
        assertTrue(Game.isTrinca(numberArray));
    }

    @Test
    public void isParTeste() {
        int[] numberArray = {0, 0, 1, 1, 1, 2};
        assertTrue(Game.isPar(numberArray));
    }

    @Test
    public void isNotQuinaTeste() {
        int[] numberArray = {0, 0, 0, 0, 1, 4};
        assertFalse(Game.isQuina(numberArray));
    }

    @Test
    public void isNotSequenciaTeste() {
        int[] numberArray = {1, 1, 1, 0, 1, 1};
        assertFalse(Game.isSequencia(numberArray));
    }

    @Test
    public void isNotQuadraTeste() {
        int[] numberArray = {0, 0, 0, 1, 1, 3};
        assertFalse(Game.isQuadra(numberArray));
    }

    @Test
    public void isNotTrincaParTeste() {
        int[] numberArray = {0, 0, 0, 1, 2, 3};
        assertFalse(Game.isTrincaPar(numberArray));
    }

    @Test
    public void isNotTrincaTeste() {
        int[] numberArray = {0, 0, 0, 1, 2, 2};
        assertFalse(Game.isTrinca(numberArray));
    }

    @Test
    public void isNotParTeste() {
        int[] numberArray = {1, 0, 1, 1, 1, 1};
        assertFalse(Game.isPar(numberArray));
    }
}
