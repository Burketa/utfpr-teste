package megazordmastercard;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author burca
 */
public class Megazord {

    ArrayList rangers = new ArrayList();

    public boolean isAssembled(Ranger[] rangers) {
        for (Ranger ranger : rangers) {
            if (!ranger.isOnMegazord) {
                return false;
            }
        }
        return true;
    }

    public void isReadyToFight(Ranger[] rangers) {
        if (isAssembled(rangers)) {
            System.out.println("sistemas 100%");
        }
        System.out.println("comecando a luta");
    }
}
