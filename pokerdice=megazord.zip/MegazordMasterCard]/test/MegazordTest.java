/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import megazordmastercard.Megazord;
import megazordmastercard.Ranger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Aluno
 */
public class MegazordTest {

    public MegazordTest() {
    }

    @Test
    public void CT1() {
        Megazord megazord = new Megazord();
        Ranger[] rangers = {new Ranger("vermelho", true),
            new Ranger("amarelo", true),
            new Ranger("rosa", true), new Ranger("verde", true),
            new Ranger("azul", true)};

        assertTrue(megazord.isAssembled(rangers));
        megazord.isReadyToFight(rangers);
    }

    @Test
    public void CT2() {
        Megazord megazord = new Megazord();
        Ranger[] rangers = {new Ranger("vermelho", false),
            new Ranger("amarelo", true),
            new Ranger("rosa", true), new Ranger("verde", true),
            new Ranger("azul", true)};

        assertTrue(megazord.isAssembled(rangers));
        megazord.isReadyToFight(rangers);
    }
}
