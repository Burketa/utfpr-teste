package pokerdice;

import java.util.Arrays;

/**
 *
 * @author burca
 */
public class Pokerdice {

    public static void main(String[] args) {
        Controller generator = new Controller();

        int[] player1 = new int[5];
        int[] player2 = new int[5];

        for (int i = 0; i < 5; i++) {
            player1[i] = Controller.generateRandomDiceNumber();
            player2[i] = Controller.generateRandomDiceNumber();
        }

        Controller.printScores(player1, player2);

        System.out.println("Avaliando Player 1:");
        int player1Score = Controller.calculateScore(player1);

        System.out.println("Avaliando Player 2:");
        int player2Score = Controller.calculateScore(player2);

        System.out.println("Calculando Vencedor:");
        int winnerPlayer = Controller.compareScores(player1Score, player2Score);

        if (player1Score == player2Score) {
            winnerPlayer = Controller.untie(player1, player2);
        }

        System.out.println("\n\tO jogador " + winnerPlayer + " venceu !");

    }
}
